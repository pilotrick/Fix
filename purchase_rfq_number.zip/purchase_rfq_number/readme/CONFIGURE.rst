To configure this module, you need to:

* Go to **Purchases -> Configuration and uncheck 'Use same enumeration for purchase rfq and purchase orders'.**
* Go to **Purchases -> Configuration and check 'Auto attachment requests for quotation after confirm'.**
